package com.example.aula3resumo

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
