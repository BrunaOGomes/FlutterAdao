import 'package:flutter/material.dart';

class ExibicaoClienteScreen extends StatefulWidget {
  final String title;

  const ExibicaoClienteScreen({super.key, required this.title});

  @override
  State<ExibicaoClienteScreen> createState() =>  _ExibicaoClienteScreenState();
}

class _ExibicaoClienteScreenState extends State<ExibicaoClienteScreen> {
  List<Map<String ,dynamic>>clientes=[];
  @override
  void initState() {
  clientes.add({"nome":"Carlos","idade":36});
  clientes.add({"nome":"Bruna","idade":21});
  clientes.add({"nome":"Adao","idade":9});
    super.initState();
  }

  Widget formatarTexto(String nome,int idade){
  String eMaior = idade >=18 ? "é maior de idade":"menor de idade";
  return Text("Cliente $nome $eMaior");
}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Column(
        children: [
          Text("Clientes"),
          //aqui é um cliente percorrendo a lista de clientes
          for(var cliente in clientes)
          formatarTexto(cliente["nome"], cliente["idade"])        
],
      ),
    );
  }
}