void main() {
  // ------Definição de variaveis --------------
  String name = "Bruna";
  int age = 36;
  double height = 1.58;
  var city = "Sampa";
  dynamic qualquerCoisa = "Vila Guarani";

  print(
    "Nome: $name,Age: $age ,Altura: $height,Cidade: $city,Bairro: $qualquerCoisa",
  );

  //Condicionais
  if (age > 18) {
    print("Cé o fodao mesmo hein");
  } else {
    print("Pesou o clima ");
  }

  switch(city){
    case "Sampa":
    print("Grande cidade");
    break;
    case "Ilheus":
    print("Cidade humilde");
    default:
    print("K.O mó nada a ver");
    break;
  }

  //Laços de repeticao

  for (int i = 0; i < 10; i++) {
    print("I: $i");
  }
  int i= 0;
  while(i<3){
    print("Indice: $i");
    i++;
  }
  int j=0;
  do{
    print("indice: $j");
    j++;
  }while(j<3);

  //Listas 
}
