package com.example.auladois

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
