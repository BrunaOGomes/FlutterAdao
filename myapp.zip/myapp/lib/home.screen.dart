import 'package:flutter/material.dart';
import 'package:myapp/domain/person.dart';
import 'package:myapp/domain/student.dart';
import 'package:myapp/domain/teacher.dart';

class HomeScreen extends StatefulWidget {
  final String title;
  //const com key e title sempre que feita essa constante
  const HomeScreen({super.key, required this.title});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Person person;
  late Teacher teacher;
  late Student student;
  @override
  void initState() {
    person = Person(name: "bruna", age: 21, height: 1.57);
    teacher = Teacher(name: "otaro", age: 70, height: 1.88);
    student = Student(name: "bobao", age: 30, height: 1.48);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    //Scaffold =passsa uma pré tela codada
    return Scaffold(
      //tipo o header
      appBar: AppBar(title: Text(widget.title)),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Informações da pessoa",style: TextStyle(fontWeight: FontWeight.bold),),
          Text(person.presenter()),
          Text("Informações do professor"),
          Text(teacher.presenter()),
          Text("Informações do aluno"),
          Text(student.presenter()),
        ],
      ),
    );
  }
}
